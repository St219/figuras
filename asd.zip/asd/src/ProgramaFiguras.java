import java.util.Scanner;

public class ProgramaFiguras {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Seleccione una figura geométrica:");
        System.out.println("1. Triángulo");
        System.out.println("2. Cuadrado");
        System.out.println("3. Círculo");
        int opcionFigura = scanner.nextInt();

        Figura figura;
        switch (opcionFigura) {
            case 1:
                figura = crearTriangulo(scanner);
                break;
            case 2:
                figura = crearCuadrado(scanner);
                break;
            case 3:
                figura = crearCirculo(scanner);
                break;
            default:
                System.out.println("Opción inválida. Saliendo del programa.");
                return;
        }

        System.out.println("Seleccione qué desea calcular:");
        System.out.println("1. Área");
        System.out.println("2. Perímetro");
        int opcionCalculo = scanner.nextInt();

        double resultado;
        switch (opcionCalculo) {
            case 1:
                resultado = figura.calcularArea();
                System.out.println("El área de la figura es: " + resultado);
                break;
            case 2:
                resultado = figura.calcularPerimetro();
                System.out.println("El perímetro de la figura es: " + resultado);
                break;
            default:
                System.out.println("Opción inválida. Saliendo del programa.");
                return;
        }
    }

    private static Triangulo crearTriangulo(Scanner scanner) {
        System.out.println("Ingrese la base del triángulo:");
        double base = scanner.nextDouble();

        System.out.println("Ingrese la altura del triángulo:");
        double altura = scanner.nextDouble();

        System.out.println("Ingrese el lado 1 del triángulo:");
        double lado1 = scanner.nextDouble();

        System.out.println("Ingrese el lado 2 del triángulo:");
        double lado2 = scanner.nextDouble();

        System.out.println("Ingrese el lado 3 del triángulo:");
        double lado3 = scanner.nextDouble();

        return new Triangulo(base, altura, lado1, lado2, lado3);
    }

    private static Cuadrado crearCuadrado(Scanner scanner) {
        System.out.println("Ingrese el lado del cuadrado:");
        double lado = scanner.nextDouble();

        return new Cuadrado(lado);
    }

    private static Circulo crearCirculo(Scanner scanner) {
        System.out.println("Ingrese el radio del círculo:");
        double radio = scanner.nextDouble();

        return new Circulo(radio);
    }
}